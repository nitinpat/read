dataIris <- iris

library(caret)
inTrain <- createDataPartition(y = dataIris$Species, p=0.7, list = FALSE)
training <- dataIris[inTrain, ]
dim(training)
testing <- dataIris[-inTrain, ]
dim(testing)


library(nnet)
training$Species <- relevel(training$Species, ref = "setosa")
model <- multinom(Species ~ ., data = training)
summary(model)
predict(model, newdata = testing, "probs")


pred_prob <- predict(model, newdata=testing, type="probs")

library(VGAM)
library(caret)
intrain <- createDataPartition(y = iris$Species, p = 0.7, list = FALSE)
training <- iris[intrain, ]
dim(training)

testing <- iris[-intrain, ]
dim(testing)

iris.vglm <- vglm(Species ~ ., family=multinomial, data=training)
summary(iris.vglm)

pred <- predict(iris.vglm, testing, "response")
# table(pred, testing$Species)  # giving error


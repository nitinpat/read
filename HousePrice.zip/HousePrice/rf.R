training <- read.csv(file = "D://kaggle//House Prices//newtrain.csv", 
                     header = T)
library(Boruta)
boruta.train <- Boruta(SalePrice~.-Id, data = training, doTrace = 2)
print(boruta.train)

final.boruta <- TentativeRoughFix(boruta.train)
print(final.boruta)

feature_cols <- getSelectedAttributes(final.boruta, withTentative = F)
finaltraining <- training[, c(feature_cols, "SalePrice")]

# randomForest Model
library(randomForest)
# finaltraining$GarageYrBlt <- as.integer(finaltraining$GarageYrBlt)
randomForestModel <- randomForest(formula = SalePrice ~ .-GarageYrBlt, 
                                  data = finaltraining)
# testing$GarageYrBlt <- as.integer(testing$GarageYrBlt)
testing <- read.csv(file = "D://kaggle//House Prices//newtest.csv", 
                    header = T)

levels(testing$HouseStyle) <- levels(finaltraining$HouseStyle)
levels(testing$Exterior1st) <- levels(finaltraining$Exterior1st)
levels(testing$Exterior2nd) <- levels(finaltraining$Exterior2nd)
levels(testing$Electrical) <- levels(finaltraining$Electrical)
levels(testing$GarageQual) <- levels(finaltraining$GarageQual)

predrf <- data.frame(testing$Id, predict(object = randomForestModel, 
                                       newdata = testing))
names(predrf)[1] <- "Id"
names(predrf)[2] <- "SalePrice"
sum(is.na(predrf))
write.csv(x = predrf, file = "D://kaggle//House Prices//predrf.csv")

setwd("D://kaggle//House Prices//")
training <- read.csv(file = "train.csv", header = TRUE)

# Missing value Imputation
mis_val<-sapply(training, function(x) sum(is.na(x)))
print(mis_val)
percent_mis<-as.data.frame(round((mis_val/nrow(training))*100,1))
print(percent_mis)

name<-row.names(percent_mis)
pcnt_mis_var<-cbind(name,percent_mis)
row.names(pcnt_mis_var)<-NULL
colnames(pcnt_mis_var)<-c("variable","Percent.Missing")

new_var<-as.character(pcnt_mis_var$variable[which(pcnt_mis_var$Percent.Missing<=40)])
new_training<-training[new_var]
str(new_training)

train_cont <- new_training[, sapply(new_training, is.numeric)]
train_cat <- new_training[, sapply(new_training, is.factor)]

for(i in 1:ncol(train_cont)){
        train_cont[is.na(train_cont[,i]), i] <- median(train_cont[,i], na.rm = TRUE)
}

Mode <- function(x) {
        u <- unique(x)
        u[which.max(tabulate(match(x, u)))]
}

for(i in 1:ncol(train_cat)){
        train_cat[is.na(train_cat[,i]), i] <- Mode(train_cat[,i])
}

final_training <- cbind(train_cat, train_cont)

# ---------------------------------------------

# Feature Selection

library(Boruta)
boruta.train <- Boruta(SalePrice~.-Id, data = final_training, doTrace = 2)
print(boruta.train)

final.boruta <- TentativeRoughFix(boruta.train)
print(final.boruta)

feature_cols <- getSelectedAttributes(final.boruta, withTentative = F)
finaltraining <- final_training[, c(feature_cols, "SalePrice")]

# ---------------------------------------------

# Model Building

# SVM Model
library(e1071)
svmModel <- svm(formula = SalePrice ~ ., data=finaltraining)

testing1 <- read.csv(file = "D://kaggle//House Prices//test.csv", header = T)
testing <- testing1[, feature_cols]

test_cont <- testing[, sapply(testing, is.numeric)]
test_cat <- testing[, sapply(testing, is.factor)]

for(i in 1:ncol(test_cont)){
        test_cont[is.na(test_cont[,i]), i] <- median(test_cont[,i], na.rm = TRUE)
}

for(i in 1:ncol(test_cat)){
        test_cat[is.na(test_cat[,i]), i] <- Mode(test_cat[,i])
}

final_testing <- cbind(test_cat, test_cont)

levels(final_testing$HouseStyle) <- levels(finaltraining$HouseStyle)
levels(final_testing$Exterior1st) <- levels(finaltraining$Exterior1st)
levels(final_testing$Exterior2nd) <- levels(finaltraining$Exterior2nd)
levels(final_testing$Electrical) <- levels(finaltraining$Electrical)
# levels(final_testing$GarageQual) <- levels(finaltraining$GarageQual)

predsvm <- data.frame(testing1$Id, predict(object = svmModel, 
                                          newdata = final_testing))
names(predsvm)[1] <- "Id"
names(predsvm)[2] <- "SalePrice"
sum(is.na(predsvm))
write.csv(x = predsvm, file = "D://kaggle//House Prices//predsvm.csv")

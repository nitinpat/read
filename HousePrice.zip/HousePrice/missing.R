train <- read.csv(file = "D://kaggle//House Prices//train.csv", 
                     header = T)

test <- read.csv(file = "D://kaggle//House Prices//test.csv", 
                    header = T)
test$SalePrice <- rep(NA, 1459)
df <- rbind(train, test)
str(df)

# PoolQC
df$PoolQC <- as.character(df$PoolQC)
df[df$PoolArea == 0, ]$PoolQC <- rep('None', 2906)
df$PoolQC <- as.factor(df$PoolQC)

col.pred <- c("YearBuilt","YearRemodAdd", "PoolQC", "PoolArea","WoodDeckSF","OpenPorchSF","EnclosedPorch",
              "X3SsnPorch","ScreenPorch","ExterQual","ExterCond", "YrSold","SaleType","SaleCondition")
library(rpart)
qlty.rpart <- rpart(as.factor(PoolQC) ~ .,
                    data = df[!is.na(df$PoolQC),col.pred], 
                    method = "class", 
                    na.action=na.omit)
df$PoolQC[is.na(df$PoolQC)] <- predict(qlty.rpart, 
                                       df[is.na(df$PoolQC),col.pred], 
                                       type="class")
table(df$PoolQC, useNA = "ifany")

# MiscFeature
df$MiscFeature <- as.character(df$MiscFeature)
df$MiscFeature[is.na(df$MiscFeature)] <- rep('None', 2814)
df$MiscFeature <- as.factor(df$MiscFeature)

# Alley
df$Alley <- as.character(df$Alley)
df$Alley[is.na(df$Alley)] <- rep('None', 2721)
df$Alley <- as.factor(df$Alley)

# Fence
df$Fence <- as.character(df$Fence)
df$Fence[is.na(df$Fence)] <- rep('None', 2348)
df$Fence <- as.factor(df$Fence)

# FireplaceQu
df$FireplaceQu <- as.character(df$FireplaceQu)
df$FireplaceQu[is.na(df$FireplaceQu)] <- rep('None', 1420)
df$FireplaceQu <- as.factor(df$FireplaceQu)

# Garage
col.Garage <- c("GarageType", "GarageYrBlt", "GarageFinish", 
                "GarageQual","GarageCond")

df$GarageType <- as.character(df$GarageType)
df$GarageFinish <- as.character(df$GarageFinish)
df$GarageQual <- as.character(df$GarageQual)
df$GarageCond <- as.character(df$GarageCond)

df[df$GarageArea == 0 & df$GarageCars==0 & is.na(df$GarageType), 
   col.Garage] <- apply(df[df$GarageArea == 0 & df$GarageCars==0 & 
        is.na(df$GarageType), col.Garage], 2, function(x) x <- rep("None", 157))

df$GarageType <- as.factor(df$GarageType)
df$GarageFinish <- as.factor(df$GarageFinish)
df$GarageQual <- as.factor(df$GarageQual)
df$GarageCond <- as.factor(df$GarageCond)

table(is.na(df$GarageYrBlt) & is.na(df$GarageFinish) & 
              is.na(df$GarageQual) & is.na(df$GarageCond))

# Predict GarageArea
col.pred <- c("GarageType", "GarageYrBlt", "GarageFinish", "GarageQual",
              "GarageCond","YearBuilt", "GarageCars", "GarageArea")

area.rpart <- rpart(GarageArea ~ .,
                    data = df[!is.na(df$GarageArea),col.pred],
                    method = "anova",
                    na.action=na.omit)

df$GarageArea[is.na(df$GarageArea)] <- round(predict(area.rpart, df[is.na(df$GarageArea),col.pred]))

# Predict GarageCars
cars.rpart <- rpart(GarageCars ~ .,
                    data = df[!is.na(df$GarageCars),col.pred],
                    method = "anova",
                    na.action=na.omit)

df$GarageCars[is.na(df$GarageCars)] <- round(predict(cars.rpart, 
                                df[is.na(df$GarageCars),col.pred]))

# Predict GarageYrBlt
blt.rpart <- rpart(as.factor(GarageYrBlt) ~ .,
                   data = df[!is.na(df$GarageYrBlt),col.pred],
                   method = "class",
                   na.action=na.omit)

df$GarageYrBlt[is.na(df$GarageYrBlt)] <- as.numeric(as.character(predict(blt.rpart, df[is.na(df$GarageYrBlt),col.pred], 
                                                 type = "class")))

# All of the garages made during this year were unfinised,  had GarageQual and GarageCond as TA
df$GarageFinish[df$GarageType == "Detchd" &  df$GarageYrBlt == 1950 & 
                        is.na(df$GarageFinish)] <- "Unf"
df$GarageQual[df$GarageType == "Detchd" &  df$GarageYrBlt == 1950 & 
                      is.na(df$GarageQual)] <- "TA"
df$GarageCond[df$GarageType == "Detchd" &  df$GarageYrBlt == 1950 & 
                      is.na(df$GarageCond)] <- "TA"

# MSZoning
col.pred <- c("Neighborhood", "Condition1", "Condition2", "MSZoning")
msz.rpart <- rpart(as.factor(MSZoning) ~ .,
                   data = df[!is.na(df$MSZoning),col.pred],
                   method = "class",
                   na.action=na.omit)

df$MSZoning[is.na(df$MSZoning)] <- as.character(predict(msz.rpart, 
                                df[is.na(df$MSZoning),col.pred], type = "class"))

# Basement
col.bsmt <- c("TotalBsmtSF", "BsmtExposure", "BsmtCond", "BsmtQual","BsmtFinType1",
              "BsmtFinType2", "BsmtFinSF1","BsmtFinSF2", "BsmtUnfSF")

# There is one row with NA for all basement data and missing TotalBsmtSF which is assumed 0.
df$TotalBsmtSF[is.na(df$BsmtExposure) & is.na(df$TotalBsmtSF)] <- 0

col.bsmt <- c("BsmtExposure", "BsmtCond", "BsmtQual","BsmtFinType1", "BsmtFinType2")

df$BsmtExposure <- as.character(df$BsmtExposure)
df$BsmtCond <- as.character(df$BsmtCond)
df$BsmtQual <- as.character(df$BsmtQual)
df$BsmtFinType1 <- as.character(df$BsmtFinType1)
df$BsmtFinType2 <- as.character(df$BsmtFinType2)

# There are 79 rows with NA for basement data
df[df$TotalBsmtSF == 0 & is.na(df$BsmtExposure), col.bsmt] <- 
        apply(df[df$TotalBsmtSF == 0 & is.na(df$BsmtExposure), col.bsmt], 2, 
              function(x) x <- rep("None", 79))

df$BsmtExposure <- as.factor(df$BsmtExposure)
df$BsmtCond <- as.factor(df$BsmtCond)
df$BsmtQual <- as.factor(df$BsmtQual)
df$BsmtFinType1 <- as.factor(df$BsmtFinType1)
df$BsmtFinType2 <- as.factor(df$BsmtFinType2)


# Assume that all the basement info and the year the house was built can be a good predictor of any basement info.
col.pred <- c("BsmtExposure", "BsmtCond", "BsmtQual","BsmtFinType1", "BsmtFinType2",
              "TotalBsmtSF","YearBuilt")

BsmtFinType2.rpart <- rpart(as.factor(BsmtFinType2) ~ .,
                            data = df[!is.na(df$BsmtFinType2),col.pred], 
                            method = "class", 
                            na.action=na.omit)

df$BsmtFinType2[is.na(df$BsmtFinType2)] <- as.character(predict(BsmtFinType2.rpart,                                               
                                                                df[is.na(df$BsmtFinType2),col.pred], 
                                                                type="class"))

BsmtQual.rpart <- rpart(as.factor(BsmtQual) ~ .,
                        data = df[!is.na(df$BsmtQual),col.pred], 
                        method = "class", 
                        na.action=na.omit)

df$BsmtQual[is.na(df$BsmtQual)] <- as.character(predict(BsmtQual.rpart,
                                                        df[is.na(df$BsmtQual),col.pred], 
                                                        type="class"))

BsmtCond.rpart <- rpart(as.factor(BsmtCond) ~ .,
                        data = df[!is.na(df$BsmtCond),col.pred], 
                        method = "class", 
                        na.action=na.omit)

df$BsmtCond[is.na(df$BsmtCond)] <- as.character(predict(BsmtCond.rpart, 
                                                        df[is.na(df$BsmtCond),col.pred], 
                                                        type="class"))

BsmtExposure.rpart <- rpart(as.factor(BsmtExposure) ~ .,
                            data = df[!is.na(df$BsmtExposure),col.pred], 
                            method = "class", 
                            na.action=na.omit)

df$BsmtExposure[is.na(df$BsmtExposure)] <- as.character(predict(BsmtExposure.rpart,                                               
                                                                df[is.na(df$BsmtExposure),col.pred], 
                                                                type="class"))

df$BsmtFinSF1[is.na(df$BsmtFinSF1)|is.na(df$BsmtFinSF2)|is.na(df$BsmtUnfSF)] <- 0
df$BsmtFinSF2[is.na(df$BsmtFinSF1)|is.na(df$BsmtFinSF2)|is.na(df$BsmtUnfSF)] <- 0
df$BsmtUnfSF[is.na(df$BsmtFinSF1)|is.na(df$BsmtFinSF2)|is.na(df$BsmtUnfSF)] <- 0
df$BsmtFullBath[df$TotalBsmtSF == 0 & is.na(df$BsmtFullBath)] <- rep(0,2)
df$BsmtHalfBath[df$TotalBsmtSF == 0 & is.na(df$BsmtHalfBath)] <- rep(0,2)

# Since one square feet of MasVnrAreaseem to be very unlikely, let us change these 
# 3 observations with MasVnrArea = 1 to MasVnrArea = 0
df$MasVnrArea <- ifelse(df$MasVnrArea == 1,0,df$MasVnrArea)

# Assign other 4 observations with areas > 0 but having Type as None to NA, 
# which will be fixed later
df$MasVnrType[df$MasVnrArea > 0 & df$MasVnrType == "None" & !is.na(df$MasVnrType)] <- rep(NA, 4)

# There are 23 NAs for both MasVnrType and MasVnrArea. Lets assign 0 to all
# MasVnrArea and None to all MasVnrType.
df$MasVnrArea[is.na(df$MasVnrArea)] <-rep(0, 23)
df$MasVnrType[is.na(df$MasVnrType) & df$MasVnrArea == 0] <- rep("None", 23)

# There are 3 observations with MasVenType specified but has Area 0 and 
# 5 observations with Area more than 0 but Type is missing.
# Let us assign observations with Area = 0  to Type = None 
df$MasVnrType[df$MasVnrType == "BrkFace" & df$MasVnrArea == 0] <- rep("None",2)
df$MasVnrType[df$MasVnrType == "Stone" & df$MasVnrArea == 0] <- rep("None",1)

# Predict MasVnrType 
Type.rpart <- rpart(as.factor(MasVnrType) ~ MasVnrArea,
                    data = df[!is.na(df$MasVnrType),c("MasVnrType","MasVnrArea")], 
                    method = "class", 
                    na.action=na.omit)

df$MasVnrType[is.na(df$MasVnrType)] <- as.character(predict(Type.rpart, 
                df[is.na(df$MasVnrType),c("MasVnrType","MasVnrArea")],type="class"))

# Functional
# There are two observations with missing Functional data. 

# Likely predictors
col.pred <- c("OverallQual", "OverallCond", "YearBuilt", "YearRemodAdd", "ExterQual", "ExterCond","BsmtQual", 
              "BsmtCond","GarageQual", "GarageCond","SaleType", "SaleCondition", "Functional")

func.rpart <- rpart(as.factor(Functional) ~ .,
                    data = df[!is.na(df$Functional),col.pred],
                    method = "class",
                    na.action=na.omit)

df$Functional[is.na(df$Functional)] <- as.character(predict(func.rpart, df[is.na(df$Functional),col.pred], type = "class"))

# Utilities
# Likely predictors
col.pred <- c("BldgType", "HouseStyle","OverallQual", "OverallCond", "YearBuilt", "YearRemodAdd", "ExterQual", "ExterCond","BsmtQual", 
              "BsmtCond","GarageQual", "GarageCond","SaleType", "SaleCondition", "Functional", "WoodDeckSF", "OpenPorchSF", "EnclosedPorch", "X3SsnPorch", "ScreenPorch", "PoolArea","Utilities")

util.rpart <- rpart(as.factor(Utilities) ~ .,
                    data = df[!is.na(df$Utilities),col.pred],
                    method = "class",
                    na.action=na.omit)

df$Utilities[is.na(df$Utilities)] <- as.character(predict(util.rpart, df[is.na(df$Utilities),col.pred], type = "class"))

# Exterior
# Likely predictors
col.pred <- c("BldgType", "HouseStyle", "OverallQual", "OverallCond", "YearBuilt", "YearRemodAdd", "RoofStyle", "RoofMatl", "Exterior1st", "Exterior2nd", "MasVnrType", "MasVnrArea", "ExterQual", "ExterCond")

# Predict Exterior1st
ext1.rpart <- rpart(as.factor(Exterior1st) ~ .,
                    data = df[!is.na(df$Exterior1st),col.pred],
                    method = "class",
                    na.action=na.omit)

df$Exterior1st[is.na(df$Exterior1st)] <- as.character(predict(ext1.rpart, df[is.na(df$Exterior1st),col.pred], type = "class"))

# Predict Exterior2nd
ext2.rpart <- rpart(as.factor(Exterior2nd) ~ .,
                    data = df[!is.na(df$Exterior2nd),col.pred],
                    method = "class",
                    na.action=na.omit)

df$Exterior2nd[is.na(df$Exterior2nd)] <- as.character(predict(ext2.rpart, df[is.na(df$Exterior2nd),col.pred], type = "class"))

# Electrical
# Likely predictors
col.pred <- c("BldgType", "HouseStyle", "OverallQual", "OverallCond", "YearBuilt", "YearRemodAdd", "Electrical")

# Predict Electrical
elec.rpart <- rpart(as.factor(Electrical) ~ .,
                    data = df[!is.na(df$Electrical),col.pred],
                    method = "class",
                    na.action=na.omit)

df$Electrical[is.na(df$Electrical)] <- as.character(predict(elec.rpart, df[is.na(df$Electrical),col.pred], type = "class"))

# KitchenQual
col.pred <- c("BldgType", "HouseStyle", "OverallQual", "OverallCond", "YearBuilt", "YearRemodAdd", "KitchenQual")

# Predict KitchenQual
kit.rpart <- rpart(as.factor(KitchenQual) ~ .,
                   data = df[!is.na(df$KitchenQual),col.pred],
                   method = "class",
                   na.action=na.omit)

df$KitchenQual[is.na(df$KitchenQual)] <- as.character(predict(kit.rpart, df[is.na(df$KitchenQual),col.pred], type = "class"))

# LotFrontage
# Likely predictors
col.pred <- c("MSSubClass", "MSZoning", "LotFrontage", "LotArea", "Street", "Alley", "LotShape", "LandContour", "LotConfig", "LandSlope", "BldgType", "HouseStyle", "YrSold", "SaleType", "SaleCondition")

# Predict LotFrontage
frntage.rpart <- rpart(LotFrontage ~ .,
                       data = df[!is.na(df$LotFrontage),col.pred],
                       method = "anova",
                       na.action=na.omit)

# Let us plot the existing and imputed values and check if imputed values follow the same patten
df.frontage <- as.data.frame(rbind(cbind(rep("Existing", nrow(df[!is.na(df$LotFrontage),])),df[!is.na(df$LotFrontage), "LotFrontage"]),
                                   cbind(rep("Imputed", nrow(df[is.na(df$LotFrontage),])),
                                         ceiling(predict(frntage.rpart, df[is.na(df$LotFrontage),col.pred])))))

# Imputed value seem to be fine.
df$LotFrontage[is.na(df$LotFrontage)] <- ceiling(predict(frntage.rpart, df[is.na(df$LotFrontage),col.pred]))

# SaleType
# Likely predictors
col.pred <- c("MSSubClass", "MSZoning", "LotFrontage", "LotArea", "Street", "Alley", "LotShape", "LandContour", "Utilities", "LotConfig", "LandSlope", "Neighborhood", "Condition1", "Condition2", "BldgType", "HouseStyle", "OverallQual", "OverallCond", "YearBuilt", "YearRemodAdd", "ExterQual", "ExterCond", "BsmtQual", "BsmtCond", "KitchenQual", "FireplaceQu", "GarageQual", "GarageCond", "PavedDrive", "WoodDeckSF", "OpenPorchSF", "EnclosedPorch", "X3SsnPorch", "ScreenPorch", "PoolQC", "YrSold", "SaleType", "SaleCondition")

# Predict SaleType
sale.rpart <- rpart(as.factor(SaleType) ~ .,
                    data = df[!is.na(df$SaleType),col.pred],
                    method = "class",
                    na.action=na.omit)

df$SaleType[is.na(df$SaleType)] <- as.character(predict(sale.rpart, df[is.na(df$SaleType),col.pred], type = "class"))

sapply(df[,1:80], function(x) sum(is.na(x)))

df$MSSubClass <- as.factor(df$MSSubClass)
df$OverallQual <- as.factor(df$OverallQual)
df$OverallCond <- as.factor(df$OverallCond)

newtrain <- df[1:1460, ]
newtest <- df[1461:2919, ]

write.csv(x = newtrain, file = "D://kaggle//House Prices//traindataHouse.csv")
write.csv(x = newtest, file = "D://kaggle//House Prices//testdataHouse.csv")

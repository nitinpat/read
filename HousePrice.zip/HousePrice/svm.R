training <- read.csv(file = "D://kaggle//House Prices//newtrain.csv", 
                     header = T)
library(Boruta)
boruta.train <- Boruta(SalePrice~.-Id, data = training, doTrace = 2)
print(boruta.train)

final.boruta <- TentativeRoughFix(boruta.train)
print(final.boruta)

feature_cols <- getSelectedAttributes(final.boruta, withTentative = F)
finaltraining <- training[, c(feature_cols, "SalePrice")]

# SVM Model
library(e1071)
svmModel <- svm(formula = SalePrice ~ ., data=finaltraining)

testing <- read.csv(file = "D://kaggle//House Prices//newtest.csv", header = T)

levels(testing$HouseStyle) <- levels(finaltraining$HouseStyle)
levels(testing$Exterior1st) <- levels(finaltraining$Exterior1st)
levels(testing$Exterior2nd) <- levels(finaltraining$Exterior2nd)
levels(testing$Electrical) <- levels(finaltraining$Electrical)
levels(testing$GarageQual) <- levels(finaltraining$GarageQual)

predsvm <- data.frame(testing$Id, predict(object = svmModel, 
                                       newdata = testing))
names(predsvm)[1] <- "Id"
names(predsvm)[2] <- "SalePrice"
sum(is.na(predsvm))
write.csv(x = predsvm, file = "D://kaggle//House Prices//predsvm.csv")

training <- read.csv(file = "D://kaggle//House Prices//newtrain.csv", header = T)
library(Boruta)
boruta.train <- Boruta(SalePrice~.-Id, data = training, doTrace = 2)
print(boruta.train)

final.boruta <- TentativeRoughFix(boruta.train)
print(final.boruta)

feature_cols <- getSelectedAttributes(final.boruta, withTentative = F)
finaltraining <- training[, c(feature_cols, "SalePrice")]
boruta.df <- attStats(final.boruta)
class(boruta.df)

# finaltraining$GarageYrBlt <- as.integer(finaltraining$GarageYrBlt)
# linear Regression Model
lmModel <- step(lm(formula = SalePrice~., data = finaltraining))
newLMModel <- step(lm(formula = SalePrice ~ MSSubClass + MSZoning + LotFrontage + LotArea + LandContour + 
                              Neighborhood + BldgType + HouseStyle + OverallQual + OverallCond + 
                              YearBuilt + Exterior1st + MasVnrArea + ExterQual + BsmtQual + 
                              X2ndFlrSF + GrLivArea + BsmtFullBath + FullBath + BedroomAbvGr + 
                              KitchenAbvGr + KitchenQual + TotRmsAbvGrd + Functional + Fireplaces + 
                              GarageCars + GarageQual + WoodDeckSF + ScreenPorch, data = finaltraining))

finalLMModel <- lm(formula = SalePrice ~ MSZoning + LotFrontage + LotArea + LotShape + 
           LandContour + Neighborhood + BldgType + HouseStyle + OverallQual + 
           OverallCond + YearBuilt + Exterior1st + MasVnrArea + ExterQual + 
           BsmtQual + X2ndFlrSF + GrLivArea + BsmtFullBath + FullBath + 
           BedroomAbvGr + KitchenAbvGr + KitchenQual + TotRmsAbvGrd + 
           Functional + Fireplaces + GarageCars + GarageQual + WoodDeckSF, 
   data = finaltraining)

testing <- read.csv(file = "D://kaggle//House Prices//newtest.csv", header = T)
# testing$GarageYrBlt <- as.integer(testing$GarageYrBlt)
pred <- data.frame(testing$Id, predict.lm(object = finalLMModel, newdata = testing))
sum(is.na(pred))

names(pred)[1] <- "Id"
names(pred)[2] <- "SalePrice"
write.csv(x = pred, file = "D://kaggle//House Prices//predlmNew.csv")

# SVM Model
library(e1071)

svmModel <- svm(formula = SalePrice ~ ., data=finaltraining)
# (below I'm just predicting to the training dataset - it could of course just 
# as easily be a separate test dataset)
testing <- read.csv(file = "D://kaggle//House Prices//newtest.csv", header = T)
pred <- data.frame(testing$Id, predict(object = svmModel, 
                                       newdata = testing))
names(pred)[1] <- "Id"
names(pred)[2] <- "SalePrice"
sum(is.na(pred))
write.csv(x = pred, file = "D://kaggle//House Prices//predsvm.csv")

# randomForest Model
library(randomForest)
finaltraining$GarageYrBlt <- as.integer(finaltraining$GarageYrBlt)
randomForestModel <- randomForest(formula = SalePrice ~ MSZoning + LotFrontage + LotArea + LotShape + 
                                          LandContour + Neighborhood + BldgType + HouseStyle + OverallQual + 
                                          OverallCond + YearBuilt + Exterior1st + MasVnrArea + ExterQual + 
                                          BsmtQual + X2ndFlrSF + GrLivArea + BsmtFullBath + FullBath + 
                                          BedroomAbvGr + KitchenAbvGr + KitchenQual + TotRmsAbvGrd + 
                                          Functional + Fireplaces + GarageCars + GarageQual + WoodDeckSF, 
                                  data = finaltraining)
testing$GarageYrBlt <- as.integer(testing$GarageYrBlt)
predr <- predict(randomForestModel, t1)
names(predr)[1] <- "Id"
names(predr)[2] <- "SalePrice"
write.csv(x = predr, file = "D://kaggle//House Prices//predrf.csv")